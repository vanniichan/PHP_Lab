<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <title>Bai_1</title>
</head>
<body>
<?php
phpinfo();
?>
</body>
</html>

